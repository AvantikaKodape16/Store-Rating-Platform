import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function Dashboard() {
  const [stats, setStats] = useState({});
  useEffect(() => {
    const token = localStorage.getItem('token');
    axios.get('http://localhost:4000/admin/dashboard', { params: { token } })
      .then(res => setStats(res.data));
  }, []);
  return (
    <div>
      <h2>Admin Dashboard</h2>
      <p>Total Users: {stats.total_users}</p>
      <p>Total Stores: {stats.total_stores}</p>
      <p>Total Ratings: {stats.total_ratings}</p>
    </div>
  );
}