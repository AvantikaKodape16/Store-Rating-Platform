import React, { useState } from 'react';
import axios from 'axios';

export default function Signup() {
  const [form, setForm] = useState({ name: '', email: '', address: '', password: '' });
  const [msg, setMsg] = useState('');

  const onChange = e => setForm({ ...form, [e.target.name]: e.target.value });

  const onSubmit = async e => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:4000/auth/signup', form);
      setMsg('Signup successful! You can login now.');
    } catch (err) {
      setMsg(err.response?.data?.error || 'Signup failed');
    }
  };

  return (
    <form onSubmit={onSubmit}>
      <h2>Signup</h2>
      <input name="name" placeholder="Name" onChange={onChange} required minLength={20} maxLength={60} />
      <input name="email" placeholder="Email" onChange={onChange} required />
      <input name="address" placeholder="Address" onChange={onChange} required maxLength={400} />
      <input name="password" placeholder="Password" type="password" onChange={onChange} required minLength={8} maxLength={16} />
      <button type="submit">Signup</button>
      <p>{msg}</p>
    </form>
  );
}