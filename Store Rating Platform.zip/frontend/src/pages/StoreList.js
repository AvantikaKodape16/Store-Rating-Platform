import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function StoreList() {
  const [stores, setStores] = useState([]);
  const [search, setSearch] = useState('');

  useEffect(() => {
    axios.get('http://localhost:4000/stores', { params: { search } })
      .then(res => setStores(res.data));
  }, [search]);

  return (
    <div>
      <h2>Stores</h2>
      <input placeholder="Search by Name or Address" value={search} onChange={e => setSearch(e.target.value)} />
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Address</th>
            <th>Overall Rating</th>
          </tr>
        </thead>
        <tbody>
          {stores.map(s => (
            <tr key={s.id}>
              <td>{s.name}</td>
              <td>{s.address}</td>
              <td>{s.overall_rating.toFixed(2)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}