const express = require('express');
const router = express.Router();
const db = require('../db');
const jwt = require('jsonwebtoken');

// Dashboard stats
router.get('/dashboard', async (req, res) => {
  // token required, must be admin
  const { token } = req.query;
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    if (decoded.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    const users = await db.query('SELECT COUNT(*) FROM users');
    const stores = await db.query('SELECT COUNT(*) FROM stores');
    const ratings = await db.query('SELECT COUNT(*) FROM ratings');
    res.json({
      total_users: +users.rows[0].count,
      total_stores: +stores.rows[0].count,
      total_ratings: +ratings.rows[0].count
    });
  } catch (e) {
    res.status(400).json({ error: 'Invalid token' });
  }
});

// Add store/user, list/filter
// ... implement as needed

module.exports = router;