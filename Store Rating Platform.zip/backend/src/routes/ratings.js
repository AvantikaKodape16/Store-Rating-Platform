const express = require('express');
const router = express.Router();
const db = require('../db');
const jwt = require('jsonwebtoken');

// Submit or update rating
router.post('/:storeId', async (req, res) => {
  const { token, rating } = req.body;
  const { storeId } = req.params;
  if (!rating || rating < 1 || rating > 5) return res.status(400).json({ error: 'Invalid rating' });
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const userId = decoded.id;
    await db.query(`
      INSERT INTO ratings (store_id, user_id, rating)
      VALUES ($1, $2, $3)
      ON CONFLICT (store_id, user_id) DO UPDATE SET rating=$3, updated_at=NOW()
    `, [storeId, userId, rating]);
    res.json({ message: 'Rating submitted' });
  } catch (e) {
    res.status(400).json({ error: 'Invalid token' });
  }
});

module.exports = router;