const express = require('express');
const router = express.Router();
const db = require('../db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

// Helper: Validate
function validateUser({ name, email, address, password }) {
  if (!name || name.length < 20 || name.length > 60) return false;
  if (!address || address.length > 400) return false;
  if (!password || !/[A-Z]/.test(password) || !/[!@#$%^&*]/.test(password) || password.length < 8 || password.length > 16) return false;
  if (!email || !/\S+@\S+\.\S+/.test(email)) return false;
  return true;
}

// Signup
router.post('/signup', async (req, res) => {
  const { name, email, address, password } = req.body;
  if (!validateUser({ name, email, address, password })) return res.status(400).json({ error: 'Validation failed' });
  const hash = await bcrypt.hash(password, 10);
  try {
    await db.query(`INSERT INTO users (name, email, address, password, role) VALUES ($1, $2, $3, $4, 'normal')`, [name, email, address, hash]);
    res.json({ message: 'Signup successful' });
  } catch (e) {
    res.status(400).json({ error: 'Email already exists' });
  }
});

// Login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = (await db.query(`SELECT * FROM users WHERE email=$1`, [email])).rows[0];
  if (!user) return res.status(400).json({ error: 'Invalid email or password' });
  const valid = await bcrypt.compare(password, user.password);
  if (!valid) return res.status(400).json({ error: 'Invalid email or password' });
  const token = jwt.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '1d' });
  res.json({ token, user: { id: user.id, name: user.name, role: user.role } });
});

module.exports = router;