const express = require('express');
const router = express.Router();
const db = require('../db');
const jwt = require('jsonwebtoken');

// List stores & search
router.get('/', async (req, res) => {
  const { search } = req.query;
  let query = 'SELECT s.*, COALESCE(avg(r.rating),0) AS overall_rating FROM stores s LEFT JOIN ratings r ON s.id = r.store_id';
  let params = [];
  if (search) {
    query += ' WHERE LOWER(s.name) LIKE $1 OR LOWER(s.address) LIKE $2';
    params = [`%${search.toLowerCase()}%`, `%${search.toLowerCase()}%`];
  }
  query += ' GROUP BY s.id ORDER BY s.name ASC';
  const result = await db.query(query, params);
  res.json(result.rows);
});

module.exports = router;