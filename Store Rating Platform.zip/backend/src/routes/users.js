const express = require('express');
const router = express.Router();
const db = require('../db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

// Update Password
router.post('/update-password', async (req, res) => {
  const { token, oldPassword, newPassword } = req.body;
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = (await db.query('SELECT * FROM users WHERE id=$1', [decoded.id])).rows[0];
    if (!user) return res.status(404).json({ error: 'User not found' });
    if (!(await bcrypt.compare(oldPassword, user.password))) return res.status(400).json({ error: 'Incorrect password' });
    if (!/[A-Z]/.test(newPassword) || !/[!@#$%^&*]/.test(newPassword) || newPassword.length < 8 || newPassword.length > 16) return res.status(400).json({ error: 'Password policy failed' });
    const hash = await bcrypt.hash(newPassword, 10);
    await db.query('UPDATE users SET password=$1 WHERE id=$2', [hash, user.id]);
    res.json({ message: 'Password updated' });
  } catch (e) {
    res.status(400).json({ error: 'Invalid token' });
  }
});

module.exports = router;