require('dotenv').config();
const { Client } = require('pg');
const bcrypt = require('bcrypt');

const client = new Client({ connectionString: process.env.DATABASE_URL });

async function seed() {
  await client.connect();

  const password = await bcrypt.hash('Admin@123', 10);
  await client.query(`
    INSERT INTO users (name, email, address, password, role)
    VALUES ('System Administrator', 'admin@platform.com', 'HQ Address', '${password}', 'admin')
    ON CONFLICT (email) DO NOTHING;
  `);

  await client.end();
  console.log("Database seeded");
}

seed();